from scrapy.cmdline import execute
execute(['scrapy', 'crawl', 'homework_spider'])
